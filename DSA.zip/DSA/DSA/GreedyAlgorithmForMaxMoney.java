import java.util.*;
class Activity {
    int start, end, money;
    Activity(int s, int e, int m) {
        start = s;
        end = e;
        money = m;
    }
}
public class GreedyAlgorithmForMaxMoney {

    // Binary search to find the last non-conflicting activity
    static int latestNonConflict(Activity[] activities, int i) {
        int low = 0, high = i - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (activities[mid].end <= activities[i].start) {
                if (mid + 1 < i && activities[mid + 1].end <= activities[i].start) {
                    low = mid + 1;
                } else {
                    return mid;
                }
            } else {
                high = mid - 1;
            }
        }
        return -1;
    }

    // Compute maximum money using DP
    static int[] computeMaxMoney(Activity[] activities) {
        int n = activities.length;
        int[] dp = new int[n];
        dp[0] = activities[0].money;

        for (int i = 1; i < n; i++) {
            int incl = activities[i].money;
            int l = latestNonConflict(activities, i);
            if (l != -1) incl += dp[l];
            dp[i] = Math.max(incl, dp[i - 1]);
        }
        return dp;
    }

    // Print the selected activities for maximum money
    static void printSelectedActivities(Activity[] activities, int[] dp) {
        int n = activities.length;
        List<Activity> selected = new ArrayList<>();
        int i = n - 1;
        while (i >= 0) {
            int incl = activities[i].money;
            int l = latestNonConflict(activities, i);
            if (l != -1) incl += dp[l];

            if (incl > (i > 0 ? dp[i - 1] : 0)) {
                selected.add(activities[i]);
                i = l;
            } else {
                i--;
            }
        }

        Collections.reverse(selected); // Print in chronological order
        System.out.println("Selected activities for maximum money:");
        for (Activity a : selected) {
            System.out.println("Activity -> (" + a.start + "," + a.end + ") Money: " + a.money);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of activities:");
        int n = sc.nextInt();

        Activity[] activities = new Activity[n];

        System.out.println("Enter starting times:");
        int[] start = new int[n];
        for (int i = 0; i < n; i++) start[i] = sc.nextInt();

        System.out.println("Enter ending times:");
        int[] end = new int[n];5
        
        for (int i = 0; i < n; i++) end[i] = sc.nextInt();

        System.out.println("Enter money:");
        int[] money = new int[n];
        for (int i = 0; i < n; i++) money[i] = sc.nextInt();

        for (int i = 0; i < n; i++) {
            activities[i] = new Activity(start[i], end[i], money[i]);
        }

        // Sort activities by end time
        Arrays.sort(activities, Comparator.comparingInt(a -> a.end));

        // Compute maximum money
        int[] dp = computeMaxMoney(activities);
        System.out.println("Maximum money that can be earned: " + dp[n - 1]);

        // Print selected activities
        printSelectedActivities(activities, dp);
    }
}

