import java.util.*;
public class String_algorithm_to_find_palindromes {
    public static void main(String args[])
    {
        String str="abababcbacacbcacbcdabca";
        for(int i=0;i<str.length();i++)
        {
            for(int j=i+1;j<str.length();j++)
            {
                String temp=str.substring(i, j);
                
                String rev = new StringBuilder(temp).reverse().toString();

                if(temp.equals(rev) && temp.length()>5)
                {
                    System.out.println(temp);
                }
            }
        }
    }
}

