import java.util.*;
public class dynamic_programming_for_fibonacci {
    static int[] dp=new int[100];
    static int fibonacci(int n)
    {
        if(n<=1)
        {
            return n;
        }
        if(dp[n]!=-1)
        {
            return dp[n];
        }
        dp[n]=fibonacci(n-1)+fibonacci(n-2);
        return dp[n];

    }
   public static void main(String args[])
   {
    // Initialize dp array with -1
    Arrays.fill(dp, -1);
    int n=6;
    System.out.println(fibonacci(n));
   } 
}
