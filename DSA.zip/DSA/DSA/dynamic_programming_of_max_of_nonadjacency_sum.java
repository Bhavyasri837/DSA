import java.util.*;
public class dynamic_programming_of_max_of_nonadjacency_sum {

    public static int maxsum(int[] dp,int n)
    {
        int[] arr=new int[n];
        arr[0]=dp[0];
        arr[1]=Math.max(dp[0],dp[1]);
        for(int i=0;i<n;i++)
        {
            arr[i]=Math.max(arr[i-1],dp[i]+arr[i-2]);
        }
        return arr[n-1];
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int [] dp=new int[n];
        for(int i=0;i<n;i++)
        {
            dp[i]=sc.nextInt();
        }
        System.out.println(maxsum(dp, n));
    }
    
}
