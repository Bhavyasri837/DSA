import java.util.*;
public class dynamic_programming_to_find_factorial_of_a_number {
    static int[] memo;
    public static int factorial(int n)
    {
        if(n<=1)
        {
            return 1;
        }
        if(memo[n]!=-1)
        {
            return memo[n];
        }
        memo[n]=n*factorial(n-1);
        return memo[n];
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        memo=new int[n+1];
        Arrays.fill(memo,-1);
        System.out.println(factorial(n));
    }
}
 