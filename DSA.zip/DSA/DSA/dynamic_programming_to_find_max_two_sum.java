import java.util.*;
public class dynamic_programming_to_find_max_two_sum {
    public static int leader(int arr[],int n)
    {
        int[] dp=new int[n];
        dp[0]=arr[0];
        int max=dp[0];
        int count=1;
        for(int i=0;i<n;i++)
        {
            if(max<arr[i])
            {
                dp[i]=arr[i];
                max=dp[i];
                count++;
            }
        }
        return count;
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] arr=new int[n];
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        System.out.println(leader(arr, n));
    }
}
