import java.util.*;
public class greedy_algorithm_chocolates
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the array size:");
        int n=sc.nextInt();
        int[] arr=new int[n];
        System.out.println("enter array elements:");
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        System.out.println("enter the money that you have :");
        int money=sc.nextInt();
        //sorting array
        Arrays.sort(arr);
        //printing array
        System.out.println("the array is:");
        for(int i=0;i<n;i++)
        {
            System.out.println(arr[i]);
        }
        System.out.println("chocolates you can buy with your money:");
        int sum=0;
        for(int i=0;i<arr.length;i++)
        {
            if(sum+arr[i]<=money)
            {
            sum=sum+arr[i];
            System.out.println(arr[i]);
            }
            else{
                i=0;
            }
        }
    }
}