import java.util.*;
public class greedy_algorithm_number_of_notes {

    static void notesCount(int amount, int[] arr) {
        int sum=0;
        int sumnotes=0;
        for (int i = 0; i < arr.length; i++) {
            int note = amount / arr[i];
            if (note > 0) {
                System.out.println(note + " * " + arr[i] + " = " + (note * arr[i]));
                sum=sum+(note * arr[i]);
                sumnotes=sumnotes+note;
            }
            amount = amount % arr[i]; // update the remaining amount
        }
        System.out.println("total sum="+sum);
        System.out.println("sum of all notes="+sumnotes);
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int arr[] = {500, 200, 100, 50, 10};
        int amount = 25760;
        notesCount(amount, arr);
    }
}

