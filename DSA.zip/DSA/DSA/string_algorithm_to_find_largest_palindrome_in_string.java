import java.util.*;
public class string_algorithm_to_find_largest_palindrome_in_string {
public static boolean palindrome(String str)
{
    int i=0;
    int j=str.length()-1;
    while(i<j)
    {
        if(str.charAt(i)==str.charAt(j))
        {
            i++;
            j--;
        }
        else{
            return false;
        }
    }
    return true;
}
    public static void main(String args[])
    {
        String str="abababcbacacbcacbcdabca";
        String temp="";
        for(int i=0;i<str.length();i++)
        {
            for(int j=i;j<str.length()-1;j++)
            {
                String sub=str.substring(i, j+1);
                if(palindrome(sub) && temp.length()<sub.length())
                {
                    temp=sub;
                }
            }
        }
        System.out.println(temp);
    }
}
