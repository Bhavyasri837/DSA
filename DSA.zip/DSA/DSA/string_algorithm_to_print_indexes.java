import java.util.*;
public class string_algorithm_to_print_indexes
{
    public static void main(String args[])
    {
        String str="abccdacabcababcbbbabacabc";
        String target="abc";
        int n=target.length();
        System.out.println(str.length());
        for(int i=0;i<=str.length()-n;i++)
        {
            //two methods
            //using substring method
            if(str.substring(i, i+n).equals(target))
                 System.out.println(i+","+(i+1)+","+(i+2));
                //normal character comaparision
             if(str.charAt(i)=='a' && str.charAt(i+1)=='b' && str.charAt(i+2)=='c')
                 System.out.println(i+","+(i+1)+","+(i+2));
        }
    }
}