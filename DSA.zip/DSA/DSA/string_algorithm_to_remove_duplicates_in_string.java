import java.util.*;
public class string_algorithm_to_remove_duplicates_in_string {
    public static void main(String args[])
    {
        String str="mississippi";
        for(int i=0;i<str.length()-1;i++)
        {
            if(str.charAt(i)!=str.charAt(i+1))
            {
                System.out.print(str.charAt(i));
            }
        }
        System.out.println(str.charAt(str.length()-1));
    }
}
