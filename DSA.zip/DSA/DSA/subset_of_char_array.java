
public class subset_of_char_array {
//     public static void SingleSubSet(char[]arr,int index,String current){
//         if(index==arr.length){
//             //if(!current.isEmpty())//avoids printing empty subset
//             System.out.println(current+" ");
//             return;
//         }
//         //inclues current character 
//         SingleSubSet(arr,index+1,current+arr[index]+" ");
//         //exclude current character
//         SingleSubSet(arr,index+1,current);
        
//     }
        // public static void main(String[]args){
         //char[] arr={'A','B','C'};
//         SingleSubSet(arr,0,"");
//     }
// }
// //public class backtracking 
//{
public static void findsubstring(String str,int index,String current)
{
    if(index==str.length())
    {
        System.out.println(current);
        return;
    }
    findsubstring(str,index+1,current+str.charAt(index));
    findsubstring(str,index+1,current);
}
public static void main(String args[])
{
    String str="abc";
    findsubstring(str,0,"");
}
}